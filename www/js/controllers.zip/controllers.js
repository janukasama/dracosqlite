var db = null;

angular.module('starter.controllers', ['ionic', 'ngCordova'])

.run(function($ionicPlatform, $cordovaSQLite) {
  $ionicPlatform.ready(function() {
    if (window.cordova && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
    }
    if (window.StatusBar) {
      StatusBar.styleDefault();
    }
  });
})


.controller('DashCtrl', function($scope) {})

.controller('ChatsCtrl', function($scope, $ionicHistory, Chats, $cordovaSQLite, $ionicPlatform, $rootScope) {


  // With the new view caching in Ionic, Controllers are only called
  // when they are recreated or on app start, instead of every page change.
  // To listen for when this page is active (for example, to refresh data),
  // listen for the $ionicView.enter event:
  //
  //$scope.$on('$ionicView.enter', function(e) {
  //});
  $scope.sendID;
  $scope.db;
  $scope.receivingMessage;
  $scope.userName;
  $scope.operatorMessage;

  $scope.chats = Chats.all();
  $scope.remove = function(chat) {
    Chats.remove(chat);
  };


  //Initiating the ActiveMQ server connection
  $scope.initiate = function() {
      var url = "ws://localhost:61614";
      var username = "admin";
      var passcode = "password";
      var destination = "/topic/chat.thuan";

      client = Stomp.client(url);
      var headers = {
        login: 'mylogin',
        passcode: 'mypasscode',
        // additional header
        'client-id': 'thuan'
      };

      var headersq = {
        'activemq.subscriptionName': 'thuan'
      };


      function constructSessionID(id) {
        return id.replace(/:|-/g, '');
      }


      client.connect(destination, function(frame) {
        var path = constructSessionID(frame.headers.session + "");

        $rootScope.ReceiveMessage = client.subscribe('/topic/chat.*', function(message) {
          $scope.sendID = message.headers.destination;
          console.log("destination ID :" + $rootScope.sendID);
          console.debug(message);
          var msgID = constructSessionID(message.headers["message-id"] + "");
          $scope.receivingMessage = message.body;
          $scope.userName = $scope.sendID.split(".");
          $scope.userName = $scope.userName[1];


          $scope.usercreate();



          //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
          /*        if(producers.indexOf($rootScope.userName) == -1){
                     producers.push($rootScope.userName);

                      if($rootScope.userName !=path)  {
                          var newEntry = [{
                              name: $rootScope.userName,
                              lastText: 'new one',
                              face: 'img/max.png',
                               ddestination:message.headers["destination"]
                              }];

                              $scope.chats = $scope.chats.concat(newEntry);
                              console.log($rootScope.userName + '   *************************** '+$scope.chats.length);
                              }
                      }*/
          //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

          if (msgID.indexOf(path) > -1) {

            var reply = message.body + ('<p> <font size="1" color="black">' + new Date().toLocaleString() + '</font></p>');

            $('<div class="msg_b"> <div class="profile-pic-right"><img src="img/send.png"></div> <p style="color:black;">' + reply + '</p> </div>').insertBefore('.enter-msg');

          } else {

            var reply = message.body + ('<p> <font size="1" color="white">' + new Date().toLocaleString() + '</font></p>');

            $('<div class="msg_a"> <div class="profile-pic-left"> <img  src="img/receive.png"></div> <p style="color:white;">' + reply + '</p> </div>').insertBefore('.enter-msg');
          }

        }, headersq);

      });

      console.log("successfully initiated");
    }
    //end of initiation



  $scope.sendMessage = function() {

    var text = $('#user_input').val();

    if (text != '') {
      client.send($scope.sendID, {}, text); //destination
      console.log("message submitted");
      $('#user_input').val("");
      $scope.operatorMessage = text;
     
    }
       $scope.operatorcreate();

  }




  var num = 1;

  $ionicPlatform.ready(function() {
    if (window.cordova) {
      //device
      $scope.db = $cordovaSQLite.openDB({
        name: "draco.db"
      });
      //         db = $cordovaSQLite.openDB({
      //            name: "my.db",
      //            bgType: 1
      //         });
    } else {
      // browser
      $scope.db = window.openDatabase("draco.db", '1', 'draco', 1024 * 1024 * 100);
    }
    $cordovaSQLite.execute($scope.db, 'DROP TABLE IF EXISTS CHAT');
    $cordovaSQLite.execute($scope.db, 'CREATE TABLE IF NOT EXISTS CHAT (destination,usermessage,messageFrom)');
  });

  $scope.usercreate = function() {
    var query = 'INSERT INTO CHAT (destination,usermessage,messageFrom) VALUES (?,?,?)';
    var queryParam = [$scope.sendID, $scope.receivingMessage, $scope.userName];
    $cordovaSQLite.execute($scope.db, query, queryParam).then(function(res) {
      alert("Insert ID : " + res.insertId + " | " + "Rows affected : " + res.rowsAffected);
      num++;
    }, function(err) {
      alert("Error on Create");
    });
  };

  $scope.operatorcreate = function() {
    var query = 'INSERT INTO CHAT (operatormessage) VALUES (?)';
    var queryParam = [$scope.operatorMessage];
    $cordovaSQLite.execute($scope.db, query, queryParam).then(function(res) {
      alert("Insert ID : " + res.insertId + " | " + "Rows affected : " + res.rowsAffected);
      num++;
    }, function(err) {
      alert("Error on Create");
    });
  };




  $scope.read = function() {
    var query = 'SELECT * FROM CHAT';
    var queryParam = [];
    $cordovaSQLite.execute($scope.db, query, queryParam).then(function(res) {
      alert("Returned rows : " + res.rows.length);
    }, function(err) {
      alert("Error on Read");
    });
  };




  //Disconnecting the ActiveMQ server connection
  $scope.disconnect = function() {
    var exit = 'DIRROUTETOBOT';
    client.send('/topic/chat.thuan', {}, exit);


    client.disconnect(function() {
      console.log("connection disconnected!");

      $ionicHistory.goBack();
    })
  }
})




.controller('ChatDetailCtrl', function($scope, $stateParams, Chats) {
  $scope.chat = Chats.get($stateParams.chatId);
})

.controller('AccountCtrl', function($scope) {
  $scope.settings = {
    enableFriends: true
  };
});
